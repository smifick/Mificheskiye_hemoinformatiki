Source-separated numeric snapshot. See data/external_research/README.md and SHA256SUMS. No article Methods, PubChem protocols or encoder checkpoints included.
